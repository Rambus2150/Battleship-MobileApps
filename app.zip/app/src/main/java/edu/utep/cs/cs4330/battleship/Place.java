package edu.utep.cs.cs4330.battleship;

/**
 * Created by Ramon Bustamante on 2/14/2017.
 */

public class Place {
    int x_coord;
    int y_coord;
    int hit;
    int ship;
    public Place( int i, int j){

        this.x_coord=i;
        this.y_coord=j;


    }
}
